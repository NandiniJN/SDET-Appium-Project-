package appiumActivites;

import java.awt.List;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class SMSActivity {
  
	AppiumDriver<MobileElement> driver = null;

    WebDriverWait wait;

 

    @BeforeClass

    public void beforeClass() throws MalformedURLException {

        // Set the Desired Capabilities
    		DesiredCapabilities caps = new DesiredCapabilities();
    	 	caps.setCapability("deviceName", "OnePlus7TEmulator");
     	    caps.setCapability("platformName", "android");
     		caps.setCapability("automationName", "UiAutomator2");
     	    caps.setCapability("appPackage", "com.google.android.apps.messaging");
     		caps.setCapability("appActivity", ".ui.ConversationListActivity");
     		caps.setCapability("noReset", true);

 


        URL appServer = new URL("http://0.0.0.0:4723/wd/hub");

        driver = new AndroidDriver<MobileElement>(appServer, caps);

        wait = new WebDriverWait(driver, 5);

    }

 

    @Test

    public void smsTest() {

        // Locate the button to write a new message and click it

        driver.findElement(MobileBy.AccessibilityId("Start new conversation")).click();

 

        // Enter the number to send message to
        driver.findElement(By.id("com.google.android.apps.messaging:id/recipient_text_view")).click();
      //  driver.findElement(By.id("recipient_text_view")).click();
      //  driver.findElement(By.id("recipient_text_view")).sendKeys("98645780986");
        driver.findElement(By.id("com.google.android.apps.messaging:id/recipient_text_view")).sendKeys("98645780986");
        driver.findElement(By.id("com.google.android.apps.messaging:id/recipient_text_view")).sendKeys("ENTER");
       

       
        // Focus on the message text box

        driver.findElement(By.id("com.google.android.apps.messaging:id/compose_message_text")).click();
        driver.findElement(By.id("com.google.android.apps.messaging:id/compose_message_text")).sendKeys("Hello from Appium");
        
        // Send the message
        driver.findElement(MobileBy.AndroidUIAutomator("description(\"Send SMS\")")).click();
 

        // Wait for message to show

        wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.id("send_message_button_icon")));

 

        // Assertion

        String messageLocator = "resourceId(\"com.microsoft.android.smsorganizer:id/message_text_view\")";

        String sentMessageText = driver.findElement(MobileBy.AndroidUIAutomator(messageLocator)).getText();

        Assert.assertEquals(sentMessageText, "Hello from Appium");

    }

 

    @AfterClass

    public void afterClass() {

        driver.quit();

    }
}
