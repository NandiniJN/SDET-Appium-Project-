package appiumprojects;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class App_GoogleTasks {
	
	AndroidDriver<MobileElement> driver;
	WebDriverWait wait;
	
 
	
	 @Test
	    public void task() throws InterruptedException, IOException {
		 
		
		// Set the Desired Capabilities
	        DesiredCapabilities caps = new DesiredCapabilities();
	      	caps.setCapability("deviceName", "OnePlus7TEmulator");
	        caps.setCapability("platformName", "android");
	        caps.setCapability("automationName", "UiAutomator2");
	        caps.setCapability("appPackage", "com.google.android.apps.tasks");
	        caps.setCapability("appActivity", ".ui.TaskListsActivity");

	        // Instantiate Appium Driver
	        AppiumDriver<MobileElement> driver = null;
	        
	        try {
	            // Initialize driver
	            driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
	            wait = new WebDriverWait(driver, 10);
	            
	            System.out.println("Google Task app is opened ");
		 
		 //click on Get started button
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//android.widget.Button[@text='Get started']")));
		driver.findElementByXPath("//android.widget.Button[@text='Get started']").click();
		
		//click to add -  Add Complete Activity with Google Tasks
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("tasks_fab")));
		driver.findElementById("tasks_fab").click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_title")));
		driver.findElementById("add_task_title").sendKeys("Complete Activity with Google Tasks");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_done")));
		driver.findElementById("add_task_done").click();
		
		String task1 = driver.findElementByXPath("//android.widget.LinearLayout/android.widget.TextView").getText();
		System.out.println(task1);
		
		
		
		//click to add - Add Complete Activity with Google Keep
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("tasks_fab")));
		driver.findElementById("tasks_fab").click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_title")));
		driver.findElementById("add_task_title").sendKeys("Complete Activity with Google Keep");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_done")));
		driver.findElementById("add_task_done").click();
		Thread.sleep(2000);
		String task2 = driver.findElementByXPath("//android.widget.FrameLayout[@content-desc='Complete Activity with Google Keep']/android.widget.LinearLayout/android.widget.TextView").getText();
		System.out.println(task2);
		
		

		//click to add - Add Complete the second Activity Google Keep
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("tasks_fab")));
		driver.findElementById("tasks_fab").click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_title")));
		driver.findElementById("add_task_title").sendKeys("Complete the second Activity Google Keep");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add_task_done")));
		driver.findElementById("add_task_done").click();
		Thread.sleep(2000);
		String task3 = driver.findElementByXPath("//android.widget.FrameLayout[@content-desc='Complete the second Activity Google Keep']/android.widget.LinearLayout/android.widget.TextView").getText();
		System.out.println(task3);
		
		
		
		Assert.assertEquals(task1, "Complete Activity with Google Tasks");
		Assert.assertEquals(task2, "Complete Activity with Google Keep");
		Assert.assertEquals(task3, "Complete the second Activity Google Keep");
		
		Reporter.log("Verify the Google task "+task1+" Added Sucessfully");
		Reporter.log("Verify the Google task "+task2+" Added Sucessfully");
		Reporter.log("Verify the Google task "+task3+" Added Sucessfully");
		
		 driver.quit();
		 
	        } catch (MalformedURLException e) {
	            System.out.println(e.getMessage());
		 
		 
	    }

	
	 }
	 

}