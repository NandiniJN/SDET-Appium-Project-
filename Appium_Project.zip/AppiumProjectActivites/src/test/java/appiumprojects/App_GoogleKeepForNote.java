package appiumprojects;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


public class App_GoogleKeepForNote {
	
	AppiumDriver<MobileElement> driver;
	WebDriverWait wait;
	
	@BeforeClass
	public void setUp() throws MalformedURLException {
		// Set the Desired Capabilities
		 DesiredCapabilities caps = new DesiredCapabilities();
	      	caps.setCapability("deviceName", "OnePlus7TEmulator");
	        caps.setCapability("platformName", "android");
	        caps.setCapability("automationName", "UiAutomator2");
	        caps.setCapability("appPackage", "com.google.android.keep");
	        caps.setCapability("appActivity", ".activities.BrowseActivity");

        
        
     // Initialize driver
        driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);       
        
        System.out.println("Google Keep app is opened");
	}
	
	@Test
	public void GoogleKeepNotes() throws InterruptedException{
		 wait = new WebDriverWait(driver, 10);
		 
		//create New Text Note
		wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.AccessibilityId("New text note")));
		driver.findElementByAccessibilityId("New text note").click();
		Thread.sleep(2000);
		
		//Add Title and Description for the note
		wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.id("editable_title")));
		driver.findElement(MobileBy.id("editable_title")).sendKeys("First Test note");
		driver.findElement(MobileBy.id("edit_note_text")).sendKeys("details on testing");
		driver.navigate().back();
		driver.navigate().back();
		
		
		//verify Title and description
		wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.id("index_note_title")));
		String Title = driver.findElementById("index_note_title").getText();
		System.out.println("Title : "+Title);
		
		String TitleDescription = driver.findElementById("index_note_text_description").getText();
		System.out.println("Note details : "+TitleDescription);
		Assert.assertEquals(Title, "First Test note");
		Assert.assertEquals(TitleDescription, "details on testing");
		
		Reporter.log("Verify the Title : '"+Title+"' Added To Google Keep Note");
		Reporter.log("Verify the Title Description : '"+TitleDescription+"' Added To Google Keep Note");
		
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
	

}
