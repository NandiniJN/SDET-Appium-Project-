package appiumprojects;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Chromepage_ToDoList {
	
AppiumDriver<MobileElement> driver;
	
	WebDriverWait wait;
	
	@BeforeClass
	public void setUp() throws MalformedURLException {
		
		 DesiredCapabilities caps = new DesiredCapabilities();
	    caps.setCapability("deviceName", "OnePlus7TEmulator");
	    caps.setCapability("platformName", "android");
		caps.setCapability("automationName", "UiAutomator2");
		caps.setCapability("appPackage", "com.android.chrome");
		caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		caps.setCapability("noReset", true);
		
		
		URL appserver=new URL("http://localhost:4723/wd/hub");
		
		driver=new AndroidDriver<MobileElement>(appserver,caps);

		wait = new WebDriverWait(driver, 30);
		
		driver.navigate().to("https://www.training-support.net/selenium");
		
	
		
	}
	
	@Test
	public void ToDoList() throws InterruptedException {
			
		Thread.sleep(4000);	
	//	wait = new WebDriverWait(driver, 5);
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//android.widget.Button[@text='Get Started!']")));
    	
     	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	
    	//Scroll and click on Todo List        
        String getText= driver.findElement(MobileBy.AndroidUIAutomator("UiScrollable(UiSelector().scrollable(true).instance(0)).scrollForward(2).scrollIntoView(textStartsWith(\"To-Do List\"))")).getText();
        System.out.println(getText); 
        
        driver.findElementByXPath("//android.view.View[starts-with(@text,'To-Do List')]").click();
        
        
    	
			//Adding the Three Task
		//	Thread.sleep(4000);
			driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id='taskInput']")).sendKeys("Add tasks to list");
			driver.findElement(MobileBy.xpath("//android.widget.Button[@text='Add Task']")).click();
			driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id='taskInput']")).sendKeys("Get number of tasks");
			driver.findElement(MobileBy.xpath("//android.widget.Button[@text='Add Task']")).click();
			driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id='taskInput']")).sendKeys("Clear the list");
			driver.findElement(MobileBy.xpath("//android.widget.Button[@text='Add Task']")).click();
			
			//Get the First Task
			String task1 = driver.findElement(MobileBy.xpath("//android.view.View[@text='Add tasks to list']")).getText();
			driver.findElement(MobileBy.xpath("//android.view.View[@text='Add tasks to list']")).click();
			System.out.println(task1);
			
			//Get the Second Task
			String task2 = driver.findElement(MobileBy.xpath("//android.view.View[@text='Get number of tasks']")).getText();
			driver.findElement(MobileBy.xpath("//android.view.View[@text='Get number of tasks']")).click();
			System.out.println(task2);
			
			//Get the Third Task
			String task3 = driver.findElement(MobileBy.xpath("//android.view.View[@text='Clear the list']")).getText();
			driver.findElement(MobileBy.xpath("//android.view.View[@text='Clear the list']")).click();
			System.out.println(task3);
			
			//Verify all the Three Task
			Assert.assertEquals(task1, "Add tasks to list");
			Assert.assertEquals(task2, "Get number of tasks");
			Assert.assertEquals(task3, "Clear the list");
			
			Reporter.log("Verify the Task1 Created-"+ task1);
			Reporter.log("Verify the Task2 Created-"+ task2);
			Reporter.log("Verify the Task3 Created-"+ task3);
			
			 // Click on clear task
            
	   	 	driver.findElement(MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView/android.view.View/android.view.View[4]/android.view.View[3]")).click();
	 //  	 	driver.findElement(MobileBy.xpath("//android.view.View[@text,'Clear List']")).click();
			
		}
		
	
	
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
