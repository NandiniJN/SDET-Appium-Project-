package appiumprojects;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class browser_LoginForm {
  AppiumDriver<MobileElement> driver = null;
    WebDriverWait wait;
    
    @BeforeClass
    public void beforeClass() throws MalformedURLException {
        // Set the Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceName", "OnePlus7TEmulator");
	    caps.setCapability("platformName", "android");
		caps.setCapability("automationName", "UiAutomator2");
		caps.setCapability("appPackage", "com.android.chrome");
		caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		caps.setCapability("noReset", true);

        // Instantiate Appium Driver
        URL appServer = new URL("http://0.0.0.0:4723/wd/hub");
       driver = new AndroidDriver<MobileElement>(appServer, caps);
       wait = new WebDriverWait(driver, 10);
       
       
    }

    @Test
    public void Formavalidlogin() throws InterruptedException {
    	
     	 driver.get("https://www.training-support.net/selenium");
     	Thread.sleep(2000);	
     	//	wait = new WebDriverWait(driver, 5);
     	
     	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView/android.view.View/android.view.View[1]/android.widget.Button[2]"))).click();
     	
      	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
         driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView/android.view.View[2]/android.view.View[3]/android.view.View[6]/android.view.View").click();
         
     	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     	
    	driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id=\"username\"]")).sendKeys("admin");
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id=\"password\"]")).sendKeys("password");
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(MobileBy.xpath("//android.view.View/android.view.View[4]/android.view.View/android.view.View/android.widget.Button")).click();
    	
        
       String getdetails = driver.findElement(MobileBy.xpath("//android.view.View[@text='Welcome Back, admin']")).getText();
       Assert.assertEquals(getdetails, "Welcome Back, admin");
     
    	
    }
    @Test
    public void Forminvalidlogin() throws InterruptedException {
    	
    //	 driver.get("https://www.training-support.net/selenium");
    	
    		driver.navigate().back();
    		wait = new WebDriverWait(driver, 5);
    	
    
        
        driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView/android.view.View[2]/android.view.View[3]/android.view.View[6]/android.view.View").click();
        
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    
    	driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id=\"username\"]")).sendKeys("admin");
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(MobileBy.xpath("//android.widget.EditText[@resource-id=\"password\"]")).sendKeys("passcode");
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(MobileBy.xpath("//android.view.View/android.view.View[4]/android.view.View/android.view.View/android.widget.Button")).click();
    	 
        String getdetails = driver.findElement(MobileBy.xpath("//android.view.View[@text='Invalid Credentials']")).getText();
        Assert.assertEquals(getdetails, "Invalid Credentials");
        
    
    }
    }